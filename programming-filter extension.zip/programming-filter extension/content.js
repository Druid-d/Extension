// Расширенный список ключевых слов для программирования (английские + русские)
const programmingKeywords = [
    // Языки программирования
    'javascript', 'python', 'java', 'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin',
    'go', 'rust', 'typescript', 'html', 'css', 'sql', 'bash', 'shell', 'perl',
    'scala', 'haskell', 'lua', 'r', 'matlab', 'dart',
    
    // Фреймворки
    'react', 'vue', 'angular', 'node.js', 'django', 'flask', 'spring', 'laravel',
    'rails', 'express', 'next.js', 'svelte', 'jquery', 'bootstrap', 'tailwind',
    'tensorflow', 'pytorch', 'pandas', 'numpy', 'opencv',
    
    // Инструменты
    'docker', 'kubernetes', 'aws', 'azure', 'git', 'github', 'gitlab', 'jenkins',
    'linux', 'nginx', 'apache', 'postgresql', 'mongodb', 'redis', 'mysql',
    'graphql', 'rest api', 'websocket', 'webpack', 'vite',
    
    // Термины
    'algorithm', 'function', 'variable', 'array', 'object', 'class', 'inheritance',
    'recursion', 'sorting', 'database', 'query', 'cache', 'memory', 'pointer',
    'debugging', 'compiling', 'refactoring', 'deployment', 'testing',
    'commit', 'push', 'pull', 'merge', 'branch', 'repository', 'loop', 'iteration',
    'recursion', 'stack', 'queue', 'tree', 'graph', 'hashmap', 'dictionary',
    'api', 'endpoint', 'middleware', 'callback', 'promise', 'async', 'await',
    'thread', 'concurrency', 'parallelism', 'mutex', 'semaphore',
    'code', 'coding', 'programming', 'development', 'software', 'web dev',
    
    // Обучение
    'tutorial', 'documentation', 'stackoverflow', 'leetcode', 'hackerrank',
    'codecademy', 'udemy', 'coursera', 'freecodecamp', 'w3schools', 'mdn',
    'github', 'gitlab', 'bitbucket', 'jira', 'confluence',
    
    // Русские
    'программирование', 'разработка', 'код', 'алгоритм', 'функция',
    'переменная', 'массив', 'объект', 'класс', 'отладка', 'компиляция',
    'рефакторинг', 'деплой', 'тестирование', 'коммит', 'репозиторий',
    'фреймворк', 'библиотека', 'запрос', 'сервер', 'клиент', 'бэкенд', 'фронтенд',
    'цикл', 'условие', 'ветвление', 'рекурсия', 'стек', 'очередь'
];

// ❌ ЧЁРНЫЙ СПИСОК: термины из других наук (АНГЛИЙСКИЕ + РУССКИЕ)
const nonProgrammingKeywords = [
    // ==================== БИОЛОГИЯ (ENGLISH) ====================
    'biology', 'biological', 'cell', 'cellular', 'dna', 'rna', 'gene', 'genetics',
    'evolution', 'species', 'population', 'homeostasis', 'metabolism', 'photosynthesis',
    'mitochondria', 'organelle', 'cytoplasm', 'membrane', 'protein', 'enzyme',
    'hormone', 'neuron', 'synapse', 'ecosystem', 'biosphere', 'biome', 'habitat',
    'symbiosis', 'parasite', 'bacteria', 'virus', 'fungus', 'algae', 'plant',
    'animal', 'mammal', 'reptile', 'amphibian', 'embryology', 'anatomy',
    'physiology', 'cytology', 'histology', 'microbiology', 'biochemistry',
    'biophysics', 'biotechnology', 'clone', 'stem cell', 'sequencing',
    'chromosome', 'mitosis', 'meiosis', 'ribosome', 'lysosome', 'golgi',
    
    // ==================== ФИЗИКА (ENGLISH) ====================
    'physics', 'physical', 'quantum', 'relativistic', 'gravity', 'gravitational',
    'electromagnetism', 'thermodynamics', 'entropy', 'energy', 'momentum',
    'force', 'mass', 'velocity', 'acceleration', 'particle', 'atom', 'electron',
    'proton', 'neutron', 'photon', 'boson', 'fermion', 'quark', 'field',
    'wave', 'frequency', 'wavelength', 'interference', 'diffraction',
    'polarization', 'quantization', 'entanglement', 'superposition',
    'black hole', 'singularity', 'big bang', 'cosmology', 'astrophysics',
    'mechanics', 'kinematics', 'dynamics', 'thermodynamic', 'adiabatic',
    
    // ==================== ХИМИЯ (ENGLISH) ====================
    'chemistry', 'chemical', 'molecule', 'periodic table', 'element',
    'compound', 'reaction', 'catalysis', 'solution', 'acid', 'base', 'alkali',
    'oxidation', 'reduction', 'covalent bond', 'ionic bond', 'hydrogen bond',
    'osmosis', 'diffusion', 'polymer', 'monomer', 'crystal', 'amorphous',
    'organic chemistry', 'inorganic chemistry', 'analytical chemistry',
    'stoichiometry', 'mole', 'avogadro', 'enthalpy', 'gibbs free energy',
    
    // ==================== МАТЕМАТИКА (ENGLISH) ====================
    'mathematics', 'mathematical', 'theorem', 'proof', 'axiom', 'lemma',
    'topology', 'algebra', 'geometry', 'trigonometry', 'differentiation',
    'integration', 'derivative', 'integral', 'limit', 'series', 'matrix',
    'vector', 'tensor', 'complex number', 'differential equation',
    'calculus', 'statistics', 'probability', 'distribution', 'variance',
    
    // ==================== ИСТОРИЯ (ENGLISH) ====================
    'history', 'historical', 'war', 'revolution', 'empire', 'king', 'queen',
    'emperor', 'president', 'dictator', 'medieval', 'ancient', 'renaissance',
    'enlightenment', 'colonization', 'slavery', 'feudalism', 'capitalism',
    'socialism', 'communism', 'archaeology', 'paleontology', 'anthropology',
    
    // ==================== ГЕОГРАФИЯ (ENGLISH) ====================
    'geography', 'geological', 'continent', 'ocean', 'sea', 'river', 'mountain',
    'desert', 'climate', 'weather', 'atmosphere', 'lithosphere', 'hydrosphere',
    'tectonics', 'earthquake', 'volcano', 'mineral', 'crystal', 'sediment',
    
    // ==================== АСТРОНОМИЯ (ENGLISH) ====================
    'astronomy', 'astronomical', 'planet', 'star', 'galaxy', 'nebula',
    'comet', 'asteroid', 'meteorite', 'orbit', 'telescope', 'spectrum',
    'cosmology', 'universe', 'black hole', 'supernova', 'pulsar', 'quasar',
    'exoplanet', 'constellation', 'solar system', 'milky way',
    
    // ==================== МЕДИЦИНА (ENGLISH) ====================
    'medicine', 'medical', 'disease', 'symptom', 'diagnosis', 'treatment',
    'therapy', 'surgery', 'drug', 'medication', 'antibiotic', 'vaccine',
    'patient', 'doctor', 'physician', 'hospital', 'clinic', 'pharmacy',
    'infection', 'inflammation', 'cancer', 'tumor', 'diabetes', 'hypertension',
    
    // ==================== ПСИХОЛОГИЯ (ENGLISH) ====================
    'psychology', 'psychological', 'consciousness', 'subconscious', 'behavior',
    'emotion', 'feeling', 'perception', 'memory', 'learning', 'motivation',
    'personality', 'character', 'temperament', 'stress', 'anxiety', 'depression',
    'schizophrenia', 'psychoanalysis', 'cognitive', 'behavioral',
    
    // ==================== ФИЛОСОФИЯ (ENGLISH) ====================
    'philosophy', 'philosophical', 'ethics', 'morality', 'epistemology',
    'metaphysics', 'ontology', 'logic', 'truth', 'existence', 'reality',
    'existentialism', 'stoicism', 'nihilism',
    
    // ==================== РУССКИЕ ТЕРМИНЫ (все науки) ====================
    'биология', 'биологический', 'клетка', 'днк', 'генетика', 'эволюция',
    'гомеостаз', 'фотосинтез', 'митохондрия', 'физика', 'квантовый', 'гравитация',
    'термодинамика', 'энтропия', 'химия', 'молекула', 'реакция', 'катализ',
    'математика', 'теорема', 'интеграл', 'производная', 'история', 'война',
    'революция', 'география', 'континент', 'океан', 'астрономия', 'планета',
    'галактика', 'медицина', 'болезнь', 'лечение', 'психология', 'сознание',
    'философия', 'этика', 'метафизика', 'искусство', 'музыка', 'литература'
];

// Паттерны кода
const codePatterns = [
    /function\s+\w+\s*\(/, /const\s+\w+\s*=/, /let\s+\w+\s*=/, /var\s+\w+\s*=/,
    /=>\s*{/, /<\/?[a-z]+>/, /```\w*\n/, /class\s+\w+/, /import\s+.*from/,
    /export\s+/, /console\.log\(/, /return\s+/, /if\s*\(/, /for\s*\(/, /while\s*\(/,
    /print\(/, /def\s+\w+\(/, /int\s+\w+\s*=/, /string\s+\w+\s*=/
];

// 🔍 НОВАЯ ФУНКЦИЯ: Проверка тематики всего сайта по заголовку и мета-тегам
function isSiteProgrammingRelated() {
    // Получаем заголовок страницы
    const title = document.title || '';
    const metaDescription = document.querySelector('meta[name="description"]')?.getAttribute('content') || '';
    const metaKeywords = document.querySelector('meta[name="keywords"]')?.getAttribute('content') || '';
    const ogTitle = document.querySelector('meta[property="og:title"]')?.getAttribute('content') || '';
    
    // Объединяем все мета-данные для анализа
    const siteMetadata = `${title} ${metaDescription} ${metaKeywords} ${ogTitle}`.toLowerCase();
    
    if (siteMetadata.length === 0) return true; // Если нет мета-данных - не блокируем
    
    // Проверяем на программные ключевые слова в мета-данных
    let programmingMatches = 0;
    for (const keyword of programmingKeywords) {
        if (siteMetadata.includes(keyword.toLowerCase())) {
            programmingMatches++;
            if (programmingMatches >= 1) {
                return true; // Нашли хотя бы одно программное слово в мета-данных
            }
        }
    }
    
    // Проверяем на анти-программные ключевые слова (другие науки)
    let nonProgrammingMatches = 0;
    for (const keyword of nonProgrammingKeywords) {
        if (siteMetadata.includes(keyword.toLowerCase())) {
            nonProgrammingMatches++;
            if (nonProgrammingMatches >= 2) {
                return false; // Нашли 2+ научных термина - сайт не про программирование
            }
        }
    }
    
    // Если нет явных признаков программирования и есть признаки других наук
    if (nonProgrammingMatches >= 1 && programmingMatches === 0) {
        return false;
    }
    
    // По умолчанию считаем, что сайт может быть связан с программированием
    return true;
}

// 🚀 НОВАЯ ФУНКЦИЯ: Блокировка всего контента сайта
let siteBlocked = false;

function blockWholeSite() {
    if (siteBlocked) return;
    
    siteBlocked = true;
    
    // Создаем оверлей для блокировки всего сайта
    const overlay = document.createElement('div');
    overlay.id = 'programming-site-blocker';
    overlay.style.cssText = `
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%) !important;
        z-index: 999999 !important;
        display: flex !important;
        justify-content: center !important;
        align-items: center !important;
        font-family: 'Courier New', monospace !important;
        backdrop-filter: blur(10px) !important;
    `;
    
    overlay.innerHTML = `
        <div style="
            background: rgba(0,0,0,0.9);
            padding: 40px;
            border-radius: 20px;
            text-align: center;
            max-width: 500px;
            margin: 20px;
            border: 2px solid #ff4444;
            box-shadow: 0 10px 40px rgba(0,0,0,0.5);
        ">
            <div style="font-size: 64px; margin-bottom: 20px;">🚫</div>
            <h1 style="color: #ff4444; margin-bottom: 20px; font-size: 28px;">Non-Programming Site Blocked</h1>
            <p style="color: #fff; margin-bottom: 20px; line-height: 1.6;">
                This site doesn't appear to be related to programming, software development, or coding.
            </p>
            <p style="color: #ffd700; margin-bottom: 30px; font-size: 14px;">
                📊 Detection based on: title, meta tags, and keywords
            </p>
            <button id="programming-disable-block" style="
                background: #ff4444;
                color: white;
                border: none;
                padding: 12px 24px;
                border-radius: 8px;
                font-size: 16px;
                cursor: pointer;
                font-weight: bold;
                transition: transform 0.2s;
            " onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                🔓 Disable Filter for This Site
            </button>
            <p style="color: #888; margin-top: 20px; font-size: 12px;">
                Or click extension icon to disable completely
            </p>
        </div>
    `;
    
    document.body.appendChild(overlay);
    
    // Добавляем кнопку отключения
    const disableBtn = document.getElementById('programming-disable-block');
    if (disableBtn) {
        disableBtn.addEventListener('click', () => {
            setFilterEnabled(false);
            overlay.remove();
            siteBlocked = false;
        });
    }
    
    // Скрываем оригинальный контент
    if (document.body) {
        document.body.style.overflow = 'hidden';
    }
    
    showStatus('🚫 Site blocked: Not programming-related', '#5c1a1a');
}

// Проверка, связан ли текст с программированием (а не с другими науками)
function isProgrammingText(text) {
    if (!text) return false;
    const lowerText = text.toLowerCase().slice(0, 2000);
    
    // Быстрая проверка на код (всегда приоритет)
    for (const pattern of codePatterns) {
        if (pattern.test(lowerText)) {
            return true;
        }
    }
    
    // Проверка на НЕ программистские термины (есть 2+ - сразу false)
    let nonProgrammingMatches = 0;
    for (const keyword of nonProgrammingKeywords) {
        if (lowerText.includes(keyword)) {
            nonProgrammingMatches++;
            if (nonProgrammingMatches >= 2) {
                return false;
            }
        }
    }
    
    // Проверка ключевых слов программирования (нужно хотя бы 2)
    let programmingMatches = 0;
    for (const keyword of programmingKeywords) {
        if (lowerText.includes(keyword)) {
            programmingMatches++;
        }
        if (programmingMatches >= 2) break;
    }
    
    // Для коротких текстов достаточно 1 ключевого слова программирования
    if (text.length < 100 && programmingMatches >= 1 && nonProgrammingMatches === 0) return true;
    
    // Для длинных текстов нужно 2 программных ключевых слова
    return programmingMatches >= 2 && nonProgrammingMatches === 0;
}

// Проверка элемента (с учетом контекста)
function shouldKeepElement(element) {
    if (!element || !element.matches) return true;
    
    // Если сайт полностью заблокирован - скрываем всё
    if (siteBlocked) return false;
    
    // Всегда сохраняем базовые элементы страницы
    if (element.matches('body, html, head, meta, link, script, style, nav, header, footer')) {
        return true;
    }
    
    // Сохраняем навигацию и меню
    if (element.matches('.navbar, .menu, .navigation, .sidebar, .header, .footer, nav, header, footer')) {
        return true;
    }
    
    // Получаем текст элемента
    const text = (element.innerText || element.textContent || '').trim();
    
    // Пустые элементы не трогаем
    if (text.length === 0) return true;
    
    // Очень короткие элементы (кнопки, иконки) - сохраняем
    if (text.length < 20 && element.children.length === 0) {
        return true;
    }
    
    // Проверяем наличие кода внутри
    const hasCode = codePatterns.some(pattern => pattern.test(element.innerHTML));
    if (hasCode) return true;
    
    // Проверяем заголовки
    if (element.matches('h1, h2, h3, h4') && text.length > 10) {
        return isProgrammingText(text);
    }
    
    // Проверяем ссылки
    if (element.matches('a') && text.length > 15) {
        const href = element.href || '';
        return isProgrammingText(text) || isProgrammingText(href);
    }
    
    // Основная проверка для обычных блоков
    return isProgrammingText(text);
}

// Защита от множественных вызовов статуса
let statusTimeout = null;
let lastStatusMessage = '';
let lastStatusTime = 0;

// Показ статуса
function showStatus(message, color) {
    if (!document.body) return;
    
    const now = Date.now();
    if (message === lastStatusMessage && (now - lastStatusTime) < 2000) {
        return;
    }
    
    lastStatusMessage = message;
    lastStatusTime = now;
    
    const existing = document.querySelector('.programming-status');
    if (existing) existing.remove();
    
    if (statusTimeout) clearTimeout(statusTimeout);
    
    const status = document.createElement('div');
    status.className = 'programming-status';
    status.textContent = message;
    status.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${color};
        color: white;
        padding: 8px 12px;
        border-radius: 8px;
        font-family: monospace;
        font-size: 11px;
        z-index: 10000;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
        pointer-events: none;
        opacity: 1;
    `;
    
    try {
        document.body.appendChild(status);
        
        statusTimeout = setTimeout(() => {
            if (status && status.remove) {
                status.style.opacity = '0';
                setTimeout(() => {
                    if (status && status.remove) status.remove();
                }, 200);
            }
            statusTimeout = null;
        }, 3000);
    } catch (e) {
        console.log('Could not show status:', e);
    }
}

// Очистка фильтров
function clearAllFilters() {
    if (!document.body) return;
    
    document.querySelectorAll('.programming-blur, .programming-keep').forEach(el => {
        if (el) {
            el.classList.remove('programming-blur', 'programming-keep');
            el.removeAttribute('data-filter-checked');
        }
    });
    
    // Удаляем блокировку сайта если она была
    const blocker = document.getElementById('programming-site-blocker');
    if (blocker) blocker.remove();
    siteBlocked = false;
    if (document.body) document.body.style.overflow = '';
}

// Применение фильтрации
let isProcessing = false;

function applyFilter() {
    if (!isFilterEnabled || !document.body || isProcessing) return;
    
    // Сначала проверяем тематику всего сайта
    if (!isSiteProgrammingRelated() && !siteBlocked) {
        blockWholeSite();
        return;
    }
    
    isProcessing = true;
    
    try {
        const elements = document.querySelectorAll('p, div, section, article, main, aside, h1, h2, h3, h4, h5, h6, span, li, a, img, iframe, video, figure, figcaption');
        
        let blurred = 0;
        
        elements.forEach(element => {
            if (!element || element.hasAttribute('data-filter-checked')) return;
            
            element.setAttribute('data-filter-checked', 'true');
            
            if (shouldKeepElement(element)) {
                element.classList.add('programming-keep');
                element.classList.remove('programming-blur');
            } else {
                element.classList.add('programming-blur');
                element.classList.remove('programming-keep');
                blurred++;
            }
        });
        
        if (blurred > 0) {
            showStatus(`🔧 Filtered ${blurred} non-programming blocks`, '#1a5c3e');
        }
    } finally {
        isProcessing = false;
    }
}

// Агрессивная фильтрация
function applyAggressiveFilter() {
    if (!isFilterEnabled || !document.body || isProcessing || siteBlocked) return;
    
    isProcessing = true;
    
    try {
        const textBlocks = document.querySelectorAll('p, div:not([data-filter-checked]), section:not([data-filter-checked]), article:not([data-filter-checked]), li:not([data-filter-checked]), span:not([data-filter-checked])');
        
        let changed = 0;
        
        textBlocks.forEach(block => {
            if (!block) return;
            
            const text = block.innerText || block.textContent;
            if (!text || text.length < 30) return;
            
            const isProg = isProgrammingText(text);
            
            if (isProg && block.classList.contains('programming-blur')) {
                block.classList.remove('programming-blur');
                block.classList.add('programming-keep');
                block.setAttribute('data-filter-checked', 'true');
                changed++;
            } else if (!isProg && !block.classList.contains('programming-keep')) {
                if (!block.classList.contains('programming-blur')) {
                    block.classList.add('programming-blur');
                    block.setAttribute('data-filter-checked', 'true');
                    changed++;
                }
            } else if (isProg) {
                block.classList.remove('programming-blur');
                block.classList.add('programming-keep');
                block.setAttribute('data-filter-checked', 'true');
            } else {
                block.setAttribute('data-filter-checked', 'true');
            }
        });
        
        if (changed > 0) {
            showStatus(`🔧 Updated filter: ${changed} blocks processed`, '#1a5c3e');
        }
    } finally {
        isProcessing = false;
    }
}

// Включение/выключение фильтра
let isFilterEnabled = true;
let observer = null;
let initCompleted = false;

function setFilterEnabled(enabled) {
    isFilterEnabled = enabled;
    
    if (enabled) {
        clearAllFilters();
        if (document.body) {
            document.querySelectorAll('[data-filter-checked]').forEach(el => {
                el.removeAttribute('data-filter-checked');
            });
            document.body.style.overflow = '';
        }
        setTimeout(() => applyFilter(), 100);
        startObserver();
        showStatus('✅ Programming filter ENABLED (site-wide detection active)', '#1a5c3e');
    } else {
        clearAllFilters();
        if (observer) {
            observer.disconnect();
            observer = null;
        }
        if (document.body) document.body.style.overflow = '';
        showStatus('❌ Programming filter DISABLED', '#5c1a1a');
    }
}

// Наблюдение за динамическим контентом
let observerTimeout = null;

function startObserver() {
    if (observer) observer.disconnect();
    if (!document.body) return;
    
    observer = new MutationObserver(() => {
        if (isFilterEnabled && document.body && !siteBlocked) {
            if (observerTimeout) clearTimeout(observerTimeout);
            observerTimeout = setTimeout(() => {
                applyAggressiveFilter();
                observerTimeout = null;
            }, 300);
        }
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// Добавление стилей
function addStyles() {
    if (!document.head) return;
    
    if (document.querySelector('#programming-filter-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'programming-filter-styles';
    style.textContent = `
        .programming-blur {
            filter: blur(8px) !important;
            cursor: help !important;
            position: relative !important;
            transition: filter 0.2s ease !important;
        }
        
        .programming-blur:hover {
            filter: blur(2px) !important;
        }
        
        .programming-blur::before {
            content: "🔬 Non-programming content" !important;
            position: absolute !important;
            top: 10px !important;
            left: 10px !important;
            background: rgba(0,0,0,0.85) !important;
            color: #ffd700 !important;
            padding: 4px 8px !important;
            border-radius: 4px !important;
            font-family: monospace !important;
            font-size: 10px !important;
            white-space: nowrap !important;
            pointer-events: none !important;
            z-index: 10001 !important;
            opacity: 0.8 !important;
        }
        
        .programming-blur:hover::before {
            opacity: 1 !important;
        }
        
        .programming-keep {
            filter: none !important;
        }
    `;
    
    try {
        document.head.appendChild(style);
    } catch (e) {
        console.log('Could not add styles:', e);
    }
}

// Инициализация
function init() {
    if (initCompleted) return;
    
    try {
        addStyles();
        
        const waitForBody = setInterval(() => {
            if (document.body) {
                clearInterval(waitForBody);
                
                chrome.storage.local.get(['filterEnabled'], (result) => {
                    const enabled = result.filterEnabled !== undefined ? result.filterEnabled : true;
                    setFilterEnabled(enabled);
                });
                
                initCompleted = true;
            }
        }, 100);
        
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'toggleFilter') {
                setFilterEnabled(request.enabled);
                sendResponse({ success: true });
            }
            return true;
        });
    } catch (e) {
        console.log('Initialization error:', e);
    }
}

// Запуск
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}