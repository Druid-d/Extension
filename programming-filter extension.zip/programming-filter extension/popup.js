// Получаем элементы
const toggle = document.getElementById('filterToggle');
const refreshBtn = document.getElementById('refreshBtn');
const infoBox = document.getElementById('infoBox');

// Загружаем сохраненное состояние при открытии popup
chrome.storage.local.get(['filterEnabled'], (result) => {
    const isEnabled = result.filterEnabled !== undefined ? result.filterEnabled : true;
    toggle.checked = isEnabled;
    updateStatus(isEnabled);
});

// Обработчик переключения
toggle.addEventListener('change', async () => {
    const isEnabled = toggle.checked;
    
    // Сохраняем состояние
    await chrome.storage.local.set({ filterEnabled: isEnabled });
    
    // Обновляем интерфейс
    updateStatus(isEnabled);
    
    // Получаем текущую активную вкладку
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Отправляем сообщение в content script
    try {
        await chrome.tabs.sendMessage(tab.id, { 
            action: 'toggleFilter', 
            enabled: isEnabled 
        });
        
        // Показываем уведомление
        showNotification(isEnabled);
    } catch (error) {
        // Если content script не загружен, перезагружаем страницу
        console.log('Reloading page to apply filter...');
        await chrome.tabs.reload(tab.id);
    }
});

// Обновление статуса в интерфейсе
function updateStatus(isEnabled) {
    if (isEnabled) {
        infoBox.innerHTML = '✅ <strong>Filter is ACTIVE</strong><br>Non-programming content is being blurred<br>Hover over blurred areas to see content';
        infoBox.style.background = '#1a3a2a';
        infoBox.style.color = '#4ade80';
    } else {
        infoBox.innerHTML = '⛔ <strong>Filter is DISABLED</strong><br>All content is visible normally<br>Click toggle to enable filtering';
        infoBox.style.background = '#3a2a2a';
        infoBox.style.color = '#f87171';
    }
}

// Показ уведомления
function showNotification(isEnabled) {
    const message = isEnabled ? 
        '🔧 Programming filter ENABLED - Non-programming content hidden' : 
        '🔧 Programming filter DISABLED - All content visible';
    
    // Отправляем сообщение на страницу для показа уведомления
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        chrome.tabs.sendMessage(tabs[0].id, {
            action: 'showNotification',
            message: message,
            isEnabled: isEnabled
        }).catch(() => {
            // Игнорируем ошибки, если страница не загружена
        });
    });
}

// Кнопка обновления страницы
refreshBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Анимация кнопки
    refreshBtn.classList.add('refreshing');
    setTimeout(() => refreshBtn.classList.remove('refreshing'), 1000);
    
    // Перезагружаем страницу
    await chrome.tabs.reload(tab.id);
});