// Фоновая служба для управления расширением

// Инициализация состояния при установке
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ filterEnabled: true });
    console.log('Programming Filter installed and enabled');
});

// Обработка клика по иконке (открывает popup по умолчанию)
chrome.action.onClicked.addListener((tab) => {
    // popup.html открывается автоматически, ничего не делаем
    console.log('Extension icon clicked');
});

// Обновление состояния при загрузке новой страницы
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        // Получаем состояние фильтра
        const result = await chrome.storage.local.get(['filterEnabled']);
        const isEnabled = result.filterEnabled !== undefined ? result.filterEnabled : true;
        
        if (isEnabled) {
            // Внедряем CSS для фильтрации
            try {
                await chrome.scripting.insertCSS({
                    target: { tabId: tabId },
                    css: `
                        .programming-filter-blur {
                            filter: blur(12px) !important;
                            background: rgba(0,0,0,0.05) !important;
                            transition: filter 0.3s ease !important;
                            cursor: pointer !important;
                        }
                        .programming-filter-blur:hover {
                            filter: blur(4px) !important;
                        }
                        .programming-relevant {
                            filter: none !important;
                        }
                    `
                });
            } catch (error) {
                // Игнорируем ошибки для специальных страниц
            }
        }
    }
});

// Обработка сообщений от popup и content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getStatus') {
        chrome.storage.local.get(['filterEnabled'], (result) => {
            sendResponse({ enabled: result.filterEnabled !== false });
        });
        return true;
    }
});